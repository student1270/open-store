package ru.gb.model;

import lombok.Data;

@Data
public class StatusHistoryDto {
    private String status;
    private String statusUpdatedAt;
}