package ru.gb.repository;

public interface WarehouseAdminRepository {
}
