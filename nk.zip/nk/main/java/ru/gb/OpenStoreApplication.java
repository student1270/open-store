package ru.gb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenStoreApplication {
	public static void main(String[] args) {
		SpringApplication.run(OpenStoreApplication.class, args);
	}

}
// https://yunsc.uz/uzb/page9.html